const help = (pushname, prefix, botName, reqXp) => {
        return `
「 *${botName}* 」

  ❏ Usuário: ${pushname}
  ❏ Registrado: ✔️
  ❏ Prefix: 「  ${prefix}  」
  ❏ Criador: ${reqXp}
╔═══════════════════
║        🌹𝐁𝐎𝐓🌹
╚═══════════════════

➸ Status: *「 Online 」*

       • ──── ✾ ──── •
       *FIGURINHAS*【✔】
       • ──── ✾ ──── •
      
➸ Comando : *${prefix}sticker* ou *${prefix}stiker*
➸ útil em : converter imagem/gif/vídeo em adesivo
➸ uso : responder imagem/gif/video ou enviar imagem/gif/video com legenda\n
➸ Comando : *${prefix}toimg*
➸ útil em : converter adesivo em imagem
➸ uso : adesivo de resposta\n

       • ─── ✾ ─── •
       *MEMES*【✔】
       • ─── ✾ ─── •
      
➸ Comando : *${prefix}meme*
➸ útil em : mandar imagens aleatórias de meme [inglês]
➸ uso : basta emviar o comando\n
➸ Comando : *${prefix}memeindo*
➸ útil em : mandar imagens aleatórias de meme [indo]
➸ uso : basta enviar o comando

       • ──── ✾ ──── •
       *OUTROS...*【✔】
       • ──── ✾ ──── •

➸ Comando : *${prefix}play*
➸ útil em : baixar músicas do youtube
➸ uso : basta enviar o comando\n
➸ Nota : Você precisa por o nome do video certinho pra ser encontrado\n
➸ Comando : *${prefix}joox*
➸ útil em : baixar músicas
➸ uso : basta enviar o comando\n
➸ Nota : Você precisa por o nome da música certinho pra ser encontrada\n
➸ Comando : *${prefix}nsfw*
➸ útil em : ativar o modo hentai
➸ uso : basta enviar o comando nsfw 1 para ativar, nsfw 0 para desativar\n
➸ Nota : Você precisa ser administrador do grupo\n
➸ Comando : *${prefix}nsfwneko*
➸ útil em : mandar imagens aleatórias de hentai neko
➸ uso : basta enviar o comando\n
➸ Comando : *${prefix}hentai*
➸ útil em : mandar imagens aleatórias de hentai
➸ uso : basta enviar o comando\n
➸ Comando : *${prefix}gtts*
➸ útil em : converter texto em fala/áudio
➸ uso : *${prefix}gtts [cc] [text]*\nexemplo : *${prefix}gtts ja Onii-chan*\n
➸ Comando : *${prefix}loli*
➸ útil em : mandar imagens aleatórias de loli
➸ uso : basta enviar o comando\n
➸ Comando : *${prefix}neko*
➸ útil em : mandar imagens aleatórias de neko
➸ uso : basta enviar o comando\n
➸ Comando : *${prefix}tomp3*
➸ útil em : baixar audio de video
➸ uso : basta enviar o comando\n
➸ Comando : *${prefix}ytmp4*
➸ útil em : baixar video do youtube
➸ uso : *${prefix}ytmp4 [link do video]*\n
➸ Comando : *${prefix}ocr*
➸ útil em : pegar o texto da foto e lhe enviar
➸ uso : responder imagem ou enviar mensagem com legenda\n
➸ Comando : *${prefix}wait*
➸ útil em : pesquisar sobre o anime por imagem [ Que anime é este/que ]
➸ uso : responder imagem ou enviar imagem com legenda\n
➸ Comando : *${prefix}setprefix*
➸ útil em : alterar o prefixo do bot
➸ uso : *${prefix}setprefix [texto|opcional]*\nexemplo : *${prefix}setprefix ?*
➸ Nota : Usado somente pelo proprietário do bot\n

       • ─── ✾ ─── •
       *GRUPO*【✔】
       • ─── ✾ ─── •
      
➸ Comando : *${prefix}linkgroup*
➸ útil em : enviar o link do grupo
➸ uso : basta enviar o comando\n
➸ Comando : *${prefix}tagall*
➸ útil em : marcar todos os membros do grupo, incluindo administradores
➸ uso : basta enviar o comando\n
➸ Nota : Você precisa ser administrador do grupo\n
➸ Comando : *${prefix}add*
➸ útil em : adicionar membro ao grupo
➸ uso : *${prefix}add 5585xxxxx*\n
➸ Nota : o bot precisa ser admin!\n
➸ Comando : *${prefix}kick*
➸ útil em : remover membros do grupo
➸ uso : *${prefix}kick e o @da pessoa*\n
➸ Nota : Você precisa ser admin e o bot também
➸ Comando : *${prefix}promote*
➸ útil em : tornar membro do grupo um administrador
➸ uso : *${prefix}promote e o @da pessoa*\n
➸ Nota : Você precisa ser admin e o bot também
➸ Comando : *${prefix}demote*
➸ útil em : tornar o administrador um membro comum
➸ uso : *${prefix}demote e o @da pessoa*\n
➸ Nota : Você precisa ser admin e o bot também

       • ────── ✾ ────── •
       *MENU DO MATEU*【✔】
       • ────── ✾ ────── •              

╔════════════════════
  ${prefix}criador
  DONO DO BOT *🔥mateu🔥*
  DUVIDAS? 👇
  WA.me/+1(579)9968046
╚════════════════════`
}

exports.help = help






